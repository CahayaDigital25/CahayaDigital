<?php
/**
 * CahayaDigital25 Main Index File
 * 
 * This serves as the entry point for the CahayaDigital25 website.
 * It handles SSL detection and InfinityFree compatibility.
 * 
 * @author CahayaDigital25
 * @version 1.0
 */

// Check for SSL errors and redirect to HTTP if needed
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' && 
    isset($_SERVER['HTTP_USER_AGENT']) && 
    strpos($_SERVER['HTTP_USER_AGENT'], 'ERR_SSL_PROTOCOL_ERROR') !== false) {
    
    // Redirect to HTTP version to fix SSL error
    $redirect_url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url", true, 301);
    exit;
}

// Domain detection for custom handling
$domain = $_SERVER['HTTP_HOST'] ?? '';
if (strpos($domain, 'cahayadigital25.rf.gd') !== false || 
    strpos($domain, 'cahayadigital25.great-site.net') !== false) {
    // InfinityFree hosting - directly include HTML content
    echo file_get_contents(__DIR__ . '/index.html');
    exit;
}

// Default fallback: redirect to index.html for SPA
header("Location: index.html");
exit;
?>

<!-- Fallback content if header redirect fails -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CahayaDigital25 - Portal Berita Indonesia</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #e53e3e;
        }
        .logo {
            font-size: 2em;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .logo .red {
            color: #e53e3e;
        }
        .logo .gray {
            color: #4a5568;
        }
        p {
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #e53e3e;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <span class="red">Cahaya</span><span class="gray">Digital</span><span class="red">25</span>
        </div>
        <h1>Selamat Datang di Portal Berita CahayaDigital25</h1>
        <p>Portal berita digital Indonesia yang menyajikan informasi terkini dengan tampilan responsif dan menarik.</p>
        <p>Halaman utama sedang dimuat. Jika Anda tidak dialihkan secara otomatis, silakan klik tombol di bawah.</p>
        <a href="index.html" class="btn">Masuk ke Portal Berita</a>
    </div>
    <script>
        // Redirect after a short delay
        setTimeout(function() {
            window.location.href = "index.html";
        }, 2000);
    </script>
</body>
</html>